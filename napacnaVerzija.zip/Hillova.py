import numpy
tabela = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
angleskaFrekv = [8.167, 1.492, 2.782, 4.253, 12.702, 2.228, 2.015, 6.094, 6.996, 0.153,
                             0.772, 4.025, 2.406, 6.749, 7.507, 1.929, 0.095, 5.987, 6.327, 9.056,
                             2.758, 0.978, 2.360, 0.150, 1.974, 0.074]

dekriptiraj = True
MIN_SUM = 100000

def Encrypt(b,k):
    
    b = preveri(b,k)
    rezultat = []
    b = matrikaBesedila(b)
    k = matrikaKljuca(k)
    #print('kluc tak', k)
    zmnozek = mnozenjeMatrik(k,b)  
    #print(len(zmnozek[1]), len(zmnozek), len(zmnozek[0]))
    col = len(zmnozek[1])
    row = len(zmnozek)
    for i in range(col):
        for j in range(row):
            rezultat.append(tabela[zmnozek[j][i]])
    #print('rez',rezultat)
    return rezultat


def Decrypt(c,k):
    b = preveri(c,k)
    odkrip = []
    c = matrikaBesedila(c)
    k = matrikaKljuca(k)
    k = inverz(k)
    produkt = mnozenjeMatrik(k,c)
    for i in range(len(produkt[0])):
        for j in range(len(produkt)):
            odkrip.append(tabela[produkt[j][i]])
    #print('odk',odkrip)
    return odkrip


def preveri(besedilo, kljuc):
    if((len(kljuc) % len(besedilo)) != 0):
        while((len(kljuc) % len(besedilo)) != 0):
            besedilo = besedilo + 'X'
    #print(besedilo)
    return besedilo

def mnozenjeMatrik(a,b):
    #print('dolzinaB', len(b))
    result = [[0 for x in range(len(b[1]))] for y in range(2)] #tukaj len(b[1]), ce ni samo vektor
    for i in range(len(a)):
        for j in range(len(b[0])):
            for k in range(len(b)):
                result[i][j] += a[i][k]*b[k][j]
            result[i][j] = result[i][j] % 26
    #print(result)
    return result

def inverz(a):
    det = (a[0][0]*a[1][1] - a[0][1]*a[1][0])%26
    det = inverzDeter(det)
    #zamenjamo a in d
    a[0][0], a[1][1] = a[1][1], a[0][0]
    a[0][1] *= -1
    a[1][0] *= -1
    for i in range(len(a)):
        for j in range(len(a)):
            a[i][j] *= det
            a[i][j] = a[i][j] %26
    #print(a)
    return a

def inverzDeter(det):
    for i in range(26):
        if(((det*i)%26) == 1):
            return i 
    return -1

def matrikaKljuca(k): #tukaj se visino in sirino, ce dimenzija > 2
    ind = 0
    matrika = [[0 for x in range(2)] for y in range(2)]
    for i in range(2):
        for j in range(2):
            matrika[j][i] = tabela.index(k[ind])
            ind += 1
    #print(matrika)
    return matrika

def matrikaBesedila(bes):
    stolpci = len(bes)/2
    matrikaB = [[0 for x in range(stolpci)] for y in range(2)]
    idx = 0
    for i in range(stolpci):
        for j in range(2):
            matrikaB[j][i]= tabela.index(bes[idx])
            idx += 1
            if(idx > len(bes)):
                break

    #print('vector',matrikaB)
    return matrikaB

def frekvence(c):
    f = []
    for i in range(26):
        #inx = tabela.index(c[i])
        f[c[i]] += 1
    for i in range(26):
        f[i] = (f[i]/len(c))*100
    return f

def frekvecneCrk(besedilo):
    k =0
    for i in range(0, len(tabela)):
        #print('besedilo',besedilo)
        #print('element', tabela[i])
        pojavitev = (besedilo.count(tabela[i])*1.0)/len(besedilo)
        #print('stPojavitev', pojavitev)
        k = k + pow(pojavitev - angleskaFrekv[i], 2)
        #print('k',k)
    return k


def findKey(c):
    dekriptiraj = False
    tempKljuc = []
    minSum = MIN_SUM
    for e in range(26):
        for f in range(26):
            for g in range(26):
                for h in range(26):
                    vmes = [[e, g], [f, h]]
                    print('c vmes',c)
                    dekr = Decrypt(c, vmes)
                    #frek = frekvence(dekr)
                    vso = frekvecneCrk(dekr)
                    if(vso < minSum):
                        minSum = vso
                        tempKljuc = vmes
    print(tempKljuc)
    return tempKljuc



print('Funckija Encrypt za besedo MIZA s kljuCem FTRW', Encrypt('MIZA', 'FTRW'))
print('Funkcija Decrypt za besedo OOVH s kljucem FTRW', Decrypt('OOVH', 'FTRW'))
#findKey('STSQALWTCJMIJMTHNFEBWZTVJWMRNNHPMFICJFNWSZSXGWPFHHAJFBNTWZTVTHIRMRCGVRJTAFXBWDIVMFWSNSTVLXIRACANWLYSIYVPJQMQNFLNMRPXSBHMWNJTIYNSZNHPHPIMNZDRWBPPNSHMSBUJMUHZXJHMWPSQHHJBMHHMWMJTAFXBWDICVETVLXIRANXFVETVUDWUHBWHEBMBSXHMWEEEHMANWUJUWWHAWWSNWZMLJXVXHWTVJTZZICACHHJTNWWTZRHWWTIYJSSUWSNSTVLWWWWHHPNSTVSNWWIYNSSOPFHMWEWHMHHMWNJTIYNSXPCQJTOQYFPBQKHMWEWHMHHMWNACHRNWHMWBSZWSIOGIICVETVLWWWWHHXANZRVZYWXUMVWZHDJHXAANHRUQZZOUNBTZTJFNSBUUMBVZSTTLHZXNWDTZELTVPPAJWTICVETVNNHPMFVZYWXUTVXBAJSQIUWWMHHMWNACHTGCTJIRGFCGVGSBYAPQITSDWISVPPNNZMWCIRMSFRSXHMWZEENFGDVBMHSYOYJHPBHLANXNNZVOSUSANTCVTVUMPSIATHYFAHEGCSPBWKNZMFWUYFIKXBMHHMWAAZWGJJAHSSWKVJANANXFVMAFSENLHMWBLZNDHMSBUJMNALWUFRSXWDMFWSVBTHLLJTYOSQWHYAGJHDJTXNNSTVMXTVJH')
